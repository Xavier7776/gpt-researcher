# LangGraph x GPT Researcher
[LangGraph](https://python.langchain.com/docs/langgraph) 是一个用于构建有状态、多角色 LLM 应用的库。
此示例使用 LangGraph 自动化对任何给定主题进行深入研究的过程。

需要 AG2 版本？请参阅 `multi_agents_ag2/` 目录和 AG2 文档页面。

## 使用场景
通过使用 LangGraph，研究过程可以利用多个具有专业技能的 Agent 显著提升深度和质量。
受 [STORM](https://arxiv.org/abs/2402.14207) 论文启发，此示例展示了一组 AI Agent 如何协作完成从规划到发布的研究全过程。

平均一次运行可生成 5-6 页研究报告，支持 PDF、Docx 和 Markdown 等多种格式。

请注意：多 Agent 使用与 GPT-Researcher 相同的模型配置。但目前仅使用 SMART_LLM。详情请参阅 [LLM 配置页面](https://docs.gptr.dev/docs/gpt-researcher/llms)。

## 多 Agent 团队
研究团队由 8 个 Agent 组成：
- **Human** — 人机协作环节，监督流程并向 Agent 提供反馈。
- **Chief Editor（主编）** — 监督研究过程并管理团队。这是使用 LangGraph 协调其他 Agent 的"主控" Agent。
- **Researcher（研究员）**(gpt-researcher) — 专门对给定主题进行深入研究的自主 Agent。
- **Editor（编辑）** — 负责规划研究大纲和结构。
- **Reviewer（审阅员）** — 根据一组标准验证研究结果的正确性。
- **Revisor（修订员）** — 根据审阅员的反馈修改研究结果。
- **Writer（撰稿人）** — 负责编译和撰写最终报告。
- **Publisher（发布员）** — 负责将最终报告发布为各种格式。

## 工作原理
总体流程基于以下阶段：
1. 规划阶段
2. 数据收集与分析
3. 审阅与修订
4. 撰写与提交
5. 发布

### 架构
<div align="center">
<img align="center" height="600" src="https://github.com/user-attachments/assets/ef561295-05f4-40a8-a57d-8178be687b18">
</div>
<br clear="all"/>

### 步骤
更具体地说（如架构图所示），流程如下：
- Browser（gpt-researcher）— 根据给定的研究任务浏览互联网进行初步研究。
- Editor（编辑）— 根据初步研究规划报告大纲和结构。
- 对每个大纲主题（并行执行）：
  - Researcher（gpt-researcher）— 对子主题进行深入研究并撰写草稿。
  - Reviewer（审阅员）— 根据一组标准验证草稿的正确性并提供反馈。
  - Revisor（修订员）— 根据审阅员反馈修改草稿直至满意。
- Writer（撰稿人）— 编译和撰写最终报告，包括引言、结论和参考文献部分。
- Publisher（发布员）— 将最终报告发布为 PDF、Docx、Markdown 等多种格式。

## 运行方法
1. 安装此根目录下所需的包，包括 `langgraph`：
    ```bash
    pip install -r requirements.txt
    ```
2. 更新环境变量，详见 [GPT-Researcher 文档](https://docs.gptr.dev/docs/gpt-researcher/llms)。

3. 运行应用：
    ```bash
    python main.py
    ```

## 使用方法
要更改研究查询和自定义报告，请编辑主目录中的 `task.json` 文件。
#### task.json 包含以下字段：
- `query` — 研究查询或任务。
- `model` — Agent 使用的 OpenAI LLM 模型。
- `max_sections` — 报告中的最大章节数。每个章节是研究查询的一个子主题。
- `max_plan_revisions` — 人工请求的最大计划修订次数，超过后工作流将以明确错误退出。设为 `null` 则依赖 LangGraph 的递归限制。
- `include_human_feedback` — 如果为 true，用户可以向 Agent 提供反馈。如果为 false，Agent 将自主工作。
- `publish_formats` — 发布报告的格式。报告将写入 `output` 目录。
- `source` — 进行研究的数据来源。选项：`web` 或 `local`。使用 local 时，请添加 `DOC_PATH` 环境变量。
- `follow_guidelines` — 如果为 true，研究报告将遵循以下准则。完成时间会更长。如果为 false，报告生成更快但可能不遵循准则。
- `guidelines` — 报告必须遵循的准则列表。
- `verbose` — 如果为 true，应用将向控制台打印详细日志。

#### 示例：
```json
{
  "query": "AI 是否处于炒作周期？",
  "model": "gpt-4o",
  "max_sections": 3,
  "max_plan_revisions": 3,
  "publish_formats": { 
    "markdown": true,
    "pdf": true,
    "docx": true
  },
  "include_human_feedback": false,
  "source": "web",
  "follow_guidelines": true,
  "guidelines": [
    "报告必须完整回答原始问题",
    "报告必须使用 APA 格式撰写",
    "报告必须使用英文撰写"
  ],
  "verbose": true
}
```

## 部署

```shell
pip install langgraph-cli
langgraph up
```

部署后，请参阅[此文档](https://github.com/langchain-ai/langgraph-example)了解如何使用流式和异步端点，以及交互式调试面板。
