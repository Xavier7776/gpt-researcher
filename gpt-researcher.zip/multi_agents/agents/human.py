import json


class HumanAgent:
    def __init__(self, websocket=None, stream_output=None, headers=None):
        self.websocket = websocket
        self.stream_output = stream_output
        self.headers = headers or {}

    async def review_plan(self, research_state: dict):
        print(f"HumanAgent websocket: {self.websocket}")
        print(f"HumanAgent stream_output: {self.stream_output}")
        task = research_state.get("task")
        layout = research_state.get("sections")

        # --- Phase 2: Financial context in human feedback prompt ---
        financial_data = research_state.get("financial_data") or {}
        fin_prefix = ""
        if financial_data:
            ticker = financial_data.get("ticker", "")
            overview = financial_data.get("overview", {})
            name = overview.get("name", ticker)
            fin_prefix = f"[金融研报 | {name} ({ticker}) | 8 段式结构] "
        # -----------------------------------------------------------

        user_feedback = None

        if task.get("include_human_feedback"):
            # Stream response to the user if a websocket is provided (such as from web app)
            if self.websocket and self.stream_output:
                try:
                    await self.stream_output(
                        "human_feedback",
                        "request",
                        f"{fin_prefix}Any feedback on this plan of topics to research? {layout}? If not, please reply with 'no'.",
                        self.websocket,
                    )
                    # because websocket is wrapped inside a CustomLogsHandler in websocket_manager
                    response = await self.websocket.websocket.receive_text()
                    print(f"Received response: {response}", flush=True)
                    response_data = json.loads(response)
                    if response_data.get("type") == "human_feedback":
                        user_feedback = response_data.get("content")
                    else:
                        print(
                            f"Unexpected response type: {response_data.get('type')}",
                            flush=True,
                        )
                except Exception as e:
                    print(f"Error receiving human feedback: {e}", flush=True)
            # Otherwise, prompt the user for feedback in the console
            else:
                user_feedback = input(
                    f"{fin_prefix}Any feedback on this plan? {layout}? If not, please reply with 'no'.\n>> "
                )

        if user_feedback and "no" in user_feedback.strip().lower():
            user_feedback = None

        plan_revision_count = research_state.get("plan_revision_count", 0)
        if user_feedback:
            plan_revision_count += 1

        print(f"User feedback before return: {user_feedback}")

        return {
            "human_feedback": user_feedback,
            "plan_revision_count": plan_revision_count,
        }
